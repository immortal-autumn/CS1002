public class W09PracticalExt {

    public static void main(String[] args) {

        Game game = new Game();

        game.play();
    }
}
