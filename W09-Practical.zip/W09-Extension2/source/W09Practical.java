public class W09Practical {

    public static void main(String[] args) {

        Game game = new Game();

        game.play();
    }
}
