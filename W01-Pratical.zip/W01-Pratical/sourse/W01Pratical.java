/**
*Powered By Elwin
*ELT Fondation Program
*Science
*/


import javabook.*;

public class W01Pratical {
	public static void main(String [] args) {
			SketchPad doodle = new SketchPad();
			doodle.setVisible(true);
	}
}
