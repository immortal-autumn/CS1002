public class W03Practical{
	public static void main(String[] args){
		price priceOne = new price();
		//System.out.println("The total cost is " + String.format("%.2cf",priceOne.getTotalCost()));
		System.out.println("The total cost is " + priceOne.getTotalCost());
		
		
	}
	
}